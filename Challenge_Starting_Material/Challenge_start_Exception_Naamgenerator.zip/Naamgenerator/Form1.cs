﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Naamgenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGenereer_Click(object sender, EventArgs e)
        {
            // Lees bestand met namen uit
            string[] Regels=File.ReadAllLines("Namen.txt");

            // Genereer willekeurig getal
            Random r = new Random();
            int n=r.Next(20);
            txtNaam.Text = Regels[n];
        }
    }
}
