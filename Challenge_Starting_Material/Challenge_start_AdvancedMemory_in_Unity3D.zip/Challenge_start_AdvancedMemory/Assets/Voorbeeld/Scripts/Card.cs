﻿using UnityEngine;
using System.Collections;

public class Card 
{
    private int CardID;
    private int PairID;
    private bool Rotated;
    private bool Completed;
    private Transform Model;

    public Card(int cardID, int pairID, Transform model)
    {
        CardID = cardID;
        PairID = pairID;
        Rotated = false;
        Model = model;
    }

    public int ID
    {
        get { return this.CardID; }
    }

    public int IDPair
    {
        get { return this.PairID; }
    }

    public bool IsRoated
    {
        get { return Rotated; }
    }

    public Transform CardModel
    {
        get { return this.Model; }
    }

    public bool Complete
    {
        get { return this.Completed; }
        set { Completed = value; }
    }

    public IEnumerator FlipCard()
    {
        int direction = Rotated ? -180 : 180;
        float time = 0.5f;
        Vector3 degrees = new Vector3(this.Model.rotation.x,this.Model.rotation.y, direction);
        var startRotation = this.Model.rotation;
        var endRotation = this.Model.rotation * Quaternion.Euler(degrees);
        var rate = 1.0f / time;
        float t = 0.0f;
        while (t < 1.0f)
        {
            t += Time.deltaTime * rate;
            this.Model.rotation = Quaternion.Slerp(startRotation, endRotation, t);
            yield return null;
        }

        this.Rotated = !this.Rotated;
    }

    public IEnumerator MoveToPosition(Vector3 endPosition)
    {
        float time = 0.5f;
        var startPosition = this.Model.position;
        var rate = 1.0f / time;
        float t = 0.0f;
        while (t < 1.0f)
        {
            t += Time.deltaTime * rate;
            this.Model.position = Vector3.Lerp(startPosition, endPosition, t);
            yield return null;
        }

        this.Model.position = endPosition;
    }

    public static bool CheckIfMachingPair(Card card1, Card card2)
    {
        return card1.PairID == card2.PairID ? true : false;
    }

}
