﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BoardManager : MonoBehaviour
{
    public static BoardManager instance;

    public Transform[] Models;
    private List<Card> Cards = new List<Card>();
    private int CardsCliked = 0;
    private Card Card1;
    private Card Card2;
    private bool BoardCreated = false;
    private int Score = 0;

    public int getScore
    {
        get { return this.Score; }
    }

    void Awake ()
    {
        instance = this;
        CreateBoard();
	}

    private void CreateBoard()
    {
        // we roepen dezelfde methode 2x aan omdat we setjes van dezelfde kaarten willen hebben.
        CreateModelsAndCards();
        CreateModelsAndCards();
        ShuffleCards();

        StartCoroutine(PositionCards());
    }

    private void CreateModelsAndCards()
    {
         for (int i = 0; i <= Models.Length - 1; i++)
         {
             Transform model = (Transform)Instantiate(Models[i]);
             Card cardTemp = new Card(i, i, model);
             Cards.Add(cardTemp);
         }
    }

    private IEnumerator PositionCards()
    {
        int id = 0;
        yield return new WaitForSeconds(1);
        WaitForSeconds wait = new WaitForSeconds(0.2f);

        for (int y = 0; y <= 3; y++)
        {
            for (int x = 0; x <= 4; x++)
            {
                Vector3 pos = new Vector3(x, y, 0);

                StartCoroutine(Cards[id].MoveToPosition(pos));
                ++id;

                yield return wait;
            }
        }

        BoardCreated = true;
    }

    private void ShuffleCards()
    {
        for (int i = 0; i < Cards.Count; i++)
        {
            Card tempI = Cards[i];
            int randomIndex = Random.Range(i, Cards.Count);
            Cards[i] = Cards[randomIndex];
            Cards[randomIndex] = tempI;
        }
    }

    private int CheckWhichObjectClicked(Vector3 hitLocation)
    {
        // Om te bepalen welke kaart we hebben aangeklikt, gaan we door de lijst van kaarten en vergelijken
        // we hun positie met de plaats waar je geklikt hebt.
        // De kaart met de kleinste afstand moet de kaart zijn die je aangeklikt hebt. 
        float smallestDistance = 100f;
        int ID = 0;

        for (int i = 0; i < Cards.Count; i++)
        {
            float Distance = Vector3.Distance(hitLocation, Cards[i].CardModel.position);

            if (Distance < smallestDistance)
            {
                smallestDistance = Distance;
                ID = i;
            }
        }
        return ID;
    }

    private IEnumerator CheckIfCardsMatch()
    {
        // We geven wat tijd mee hier zodat de 2e kaart die je aanklikte tijd heeft om te draaien.
        yield return new WaitForSeconds(1);

        bool matching = Card.CheckIfMachingPair(Card1, Card2);

        if (matching)
        {
            Debug.Log("match");
            Card1.Complete = matching;
            Card2.Complete = matching;
            AddScoreAndCheckIfFinished();
        }
        else
        {
            Debug.Log("Wrong!");
            StartCoroutine(Card1.FlipCard());
            StartCoroutine(Card2.FlipCard());
        }
    }

    void Update()
    {
        // zodra je de linkermuisknop indrukt wordt er een "ray" afgeschoten vanuit de camera naar de muis positie
        // Als deze straal iets raakt wordt dat opgeslagen in een RaycastHit genaamd hit. 
        // Hiermee kun je de positie bepalen.
        if (Input.GetMouseButtonDown(0))
        { 
            Ray ray = GetComponent<Camera>().ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                int ID = CheckWhichObjectClicked(hit.transform.position);

                // Hier checken we of de kaart niet al gedraaid is (We laten altijd het systeem zelf de kaarten terug draaien als ze niet matchen).
                // Als alle kaarten nog niet in positie zijn mag je ook niks aanklikken.
                if (Cards[ID].IsRoated || !BoardCreated)
                    return;

                CardsCliked++;
                if (CardsCliked == 1)
                {
                    StartCoroutine(Cards[ID].FlipCard());
                    Card1 = Cards[ID];
                }
                else if (CardsCliked == 2)
                {
                    CardsCliked = 0;
                    Card2 = Cards[ID];
                    StartCoroutine(Cards[ID].FlipCard());
                    StartCoroutine(CheckIfCardsMatch());
                }

            }
        }
    }

    private void AddScoreAndCheckIfFinished()
    {
        Score += 10;
        UIManager.instance.UpdateScoreText();

        if (IsComplete())
            UIManager.instance.WinGameAnimation();

    }

    private bool IsComplete()
    {
        int count = 0;

        foreach(Card card in Cards)
        {
            if (card.Complete)
                ++count; 
        }

        return count == Cards.Count ? true : false;
    }
}
