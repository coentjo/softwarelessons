﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class InterfaceManager : MonoBehaviour
{

    // Use this for initialization
    void Awake()
    {
       
    }

    public void UpdateScoreText()
    {
        // update hier de text van de score.
    }

    public void WinGameAnimation()
    {
      //Er staat een UI Text klaar in de scene. Deze heeft een animatie.
      //Deze kan je hier laten afspelen als het spel klaar is.
    }
}

